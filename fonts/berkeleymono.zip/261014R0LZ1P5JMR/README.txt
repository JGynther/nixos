
┌┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┐
├┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┤
├─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┤
│ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │
├─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┤
│ │ │ │ │ │ │ │ │ │U│.│S│.│ │G│R│A│P│H│I│C│S│ │C│O│M│P│A│N│Y│ │ │ │ │ │ │ │ │ │
├─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┤
│ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │
├─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┤
├─────────────────────────────────────────────────────────────────────────────┤
│                                 ~~ INFO ~~                                  │
├──────────────┬──────────────────────────────────────────────────────────────┤
│ TYPEFACE     │ TX-02 Berkeley Mono™ Typeface Family                         │
│ VERSION      │ 2.004                                                        │
│ RELEASED ON  │ 2025-11-03                                                   │
│ TICKET No.   │ Y91PLV0R                                                     │
│ BUILD DATE   │ 2026-10-14 22:37:56 UTC                                      │
│ FONT COUNT   │ 4 Fonts                                                      │
│ GLYPH COUNT  │ 2580 Glyphs                                                  │
│ BUILD TIME   │ 5.16 seconds                                                 │
│ SERVICE No.  │ 3XP8XPN2Z3                                                   │
│ SERVICE      │ TS-024 Berkeley Mono™ Standard Compiler                      │
│ SERVICE TIER │ STANDARD                                                     │
│ LICENSE No.  │ 2W3N-8V3Z-710V-M4RZ                                          │
│ LICENSE      │ LT-02 Developer Font License                                 │
├──────────────┴──────────────────────────────────────────────────────────────┤
│                                ~~ FONTS ~~                                  │
├──────────────┬──────────────────────────────────────────────────────────────┤
│ TX-02-772M   │ Regular                                                      │
│ TX-02-774M   │ Oblique                                                      │
│ TX-02-7B2M   │ Bold                                                         │
│ TX-02-7B4M   │ Bold Oblique                                                 │
├──────────────┴──────────────────────────────────────────────────────────────┤
│                         ~~ BUILD SPECIFICATIONS ~~                          │
├──────────────┬──────────────────────────────────────────────────────────────┤
│ FC-001       │ 7                                                            │
│ FC-002       │ 7B                                                           │
│ FC-003       │ 24                                                           │
│ FC-004       │ zero.dotted                                                  │
│ FC-005       │ seven.european                                               │
│ FC-008       │ off                                                          │
│ FC-010       │ desktop_otf                                                  │
│ FC-016       │ typeface_name                                                │
├──────────────┴──────────────────────────────────────────────────────────────┤
│                                ~~ FILES ~~                                  │
├─────────────────────────────────────────────────────────────────────────────┤
│ BerkeleyMono-Regular.otf                                                    │
│ BerkeleyMono-Oblique.otf                                                    │
│ BerkeleyMono-Bold.otf                                                       │
│ BerkeleyMono-Bold-Oblique.otf                                               │
│ README.txt                                                                  │
├─────────────────────────────────────────────────────────────────────────────┤
│                         ~~ LOGS (2026-10-14 UTC) ~~                         │
├──────────────┬──────────────────────────────────────────────────────────────┤
│ 22:37:51.724 │ INIT: Querying database for build ticket information         │
│ 22:37:51.726 │ INIT: Generated Package ID: 261014R0LZ1P5JMR                 │
│ 22:37:51.726 │ INIT: Loading static font compiler                           │
│ 22:37:51.727 │ FEATURES: Processing FC-010: Set OTF format                  │
│ 22:37:51.811 │ FEATURES: Processing FC-004: Target: zero, Source: zero.dott │
│ 22:37:51.812 │ FEATURES: Processing FC-005: Target: seven, Source: seven.eu │
│ 22:37:53.524 │ INTERPOLATE: Regular                                         │
│ 22:37:54.140 │ INTERPOLATE: Oblique                                         │
│ 22:37:54.178 │ INTERPOLATE: Bold                                            │
│ 22:37:54.217 │ INTERPOLATE: BoldOblique                                     │
│ 22:37:54.282 │ INTERPOLATE: Interpolating 4 instances                       │
│ 22:37:54.283 │ COMPILE: OTF, BerkeleyMono-Regular                           │
│ 22:37:54.801 │ DISK IO: Saving BerkeleyMono-Regular.otf to ramdisk          │
│ 22:37:54.859 │ COMPILE: OTF, BerkeleyMono-Oblique                           │
│ 22:37:55.376 │ DISK IO: Saving BerkeleyMono-Oblique.otf to ramdisk          │
│ 22:37:55.440 │ COMPILE: OTF, BerkeleyMono-Bold                              │
│ 22:37:55.951 │ DISK IO: Saving BerkeleyMono-Bold.otf to ramdisk             │
│ 22:37:56.012 │ COMPILE: OTF, BerkeleyMono-BoldOblique                       │
│ 22:37:56.815 │ DISK IO: Saving BerkeleyMono-Bold-Oblique.otf to ramdisk     │
│ 22:37:56.878 │ PACKAGE: Compressing font package 261014R0LZ1P5JMR.zip       │
│ 22:37:56.878 │ PACKAGE: Uploading font package to AWS S3                    │
├──────────────┴──────────────────────────────────────────────────────────────┤
│                                ~~ LEGAL ~~                                  │
├──────────────┬──────────────────────────────────────────────────────────────┤
│ COPYRIGHT    │ Copyright 2022-2026. All Rights Reserved.                    │
│              │ Intellectual Property of U.S. Graphics, LLC.                 │
├─────────────────────────────────────────────────────────────────────────────┤
├┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┤
└┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┘